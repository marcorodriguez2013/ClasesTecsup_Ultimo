package clase2_08;

public class Cuadrado extends FiguraGeometrica{

	public Cuadrado(int medida) {
		super(medida,4);
		
	}
	public double ObtenerArea() {
		return medida_lado *  medida_lado;
	}
}
