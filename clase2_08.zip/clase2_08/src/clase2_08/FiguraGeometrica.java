package clase2_08;

public abstract class FiguraGeometrica {
	int medida_lado = 10;
	int cantidad_lados = 4;

	public FiguraGeometrica(int medida, int cantidad) {
		this.medida_lado = medida;
		this.cantidad_lados = cantidad;
	}

	public double ObtenerPerimetro() {
		double res = medida_lado * cantidad_lados;
		return res;
	}

	public abstract double ObtenerArea();
}
