package clase2_08;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class Main {

	public static void main(String[] args) {
		Cuadrado c = new Cuadrado(5);
		Triangulo t = new Triangulo(4);
		
		
		ArrayList<FiguraGeometrica> lista = new ArrayList<FiguraGeometrica>();
		lista.add(c);
		lista.add(t);
		for (FiguraGeometrica f : lista) {
			System.out.println(f.ObtenerArea());
		}

	}

}
