
public class Main {

	public static void main(String[] args) {
		Periodico p = new Periodico();
		p.AgregarNoticia(new Noticias("12/08/2019", "marquito.com", "PNP captura a integrantes de banda criminal �Los cochinos de Huaycan�", "El Escuadr�n de Emergencia de la PNP desarticul� la banda criminal \"Los cochinos de Huayc�n\", quienes comet�an asaltos en la modalidad del cogoteo, en la entrada de Huayc�n en Ate Vitarte. \r\n" +  
				"Los integrantes de esta banda criminal usaban sus armas de fuego para amedrentar a sus v�ctimas y sustraerles sus pertenencias en el paradero situado en la entrada de Huayc�n. "));
		p.ImprimirNoticias();
	}

}
