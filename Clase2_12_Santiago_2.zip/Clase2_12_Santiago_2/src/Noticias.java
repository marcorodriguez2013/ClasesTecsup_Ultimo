
public class Noticias {
	String fecha;
	String nombre;		
	String titulo;
	String noticia;

	public Noticias(String fecha, String nombre, String titulo,String noticia) {
		super();
		this.fecha = fecha;
		this.nombre = nombre;
		this.titulo = titulo;
		this.noticia = noticia;
	}

	public void Imprimir() {
		System.out.println("---------------------------");
		System.out.println(fecha + " " + nombre);
		System.out.println(titulo);
		System.out.println(noticia);
		System.out.println("---------------------------");
	}

}
