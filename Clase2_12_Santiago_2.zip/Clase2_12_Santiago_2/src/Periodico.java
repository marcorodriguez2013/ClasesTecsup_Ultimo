import java.util.ArrayList;

public class Periodico {
	String nombre = "tahuantinsuyo";
	String fecha = "13/08/2019";
	ArrayList<Noticias> noticias;

	public Periodico() {
		noticias = new ArrayList<Noticias>();
	}

	public void AgregarNoticia(Noticias n) {
		noticias.add(n);
	}
	public void ImprimirNoticias() {
		System.out.println("Diario " + nombre);
		for (Noticias n : noticias) {
			n.Imprimir();
		}
	}
}
