package clase2_10_Patrick;

public class Cliente extends Persona{
	private int id_cliente;

	public Cliente(int id_cliente,String nombre, String dni, int edad) {
		super(nombre,dni,edad);
		this.id_cliente = id_cliente;		
	}

	public Cliente() {
		super();
		this.id_cliente = 0;
	}

	public int getId_cliente() {
		return id_cliente;
	}

	public void setId_cliente(int id_cliente) {
		this.id_cliente = id_cliente;
	}

	public void RegistrarCliente() {

	}

	public boolean EsMayorEdad() {
		return false;

	}
	
}
