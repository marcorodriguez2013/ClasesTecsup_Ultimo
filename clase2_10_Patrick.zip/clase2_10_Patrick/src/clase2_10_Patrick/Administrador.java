package clase2_10_Patrick;

public class Administrador extends Persona {
	private int id_administrador;

	public Administrador(int id_administrador,String nombre, String dni, int edad) {
		super(nombre,dni,edad);
		this.id_administrador = id_administrador;
	}

	public Administrador() {
		super();
		this.id_administrador = 0;
	}

	public int getId_administrador() {
		return id_administrador;
	}

	public void setId_administrador(int id_administrador) {
		this.id_administrador = id_administrador;
	}

	public void RegistrarAdmin() {

	}

	public boolean EsMayorEdad() {
		return false;

	}
}
