package clase2_10_Patrick;

public class Persona {
	private String nombre;
	private String dni;
	private int edad;

	public Persona(String nombre, String dni, int edad) {
		super();
		this.nombre = nombre;
		this.dni = dni;
		this.edad = edad;
	}

	public Persona() {
		super();
		this.nombre = "Marco Antonio Rodriguez Salinas";
		this.dni = "45463902";
		this.edad = 30;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public boolean EsMayorEdad() {
		return false;

	}

	public void Imprimir(int condicion_cliente, int condicion_administrador) {

		String nombre_clase = this.getClass().toString();
		String array[] = nombre_clase.split("\\.");
		boolean imprimir = true;
		if (array[1].equals("Cliente")) {
			if (this.getEdad() >= condicion_cliente) {
				imprimir = true;
			}else {
				imprimir = false;
			}
		}
		if (array[1].equals("Administrador")) {
			if (this.getEdad() >= condicion_administrador) {
				imprimir = true;
			}else {
				imprimir = false;
			}
		}
		if(imprimir) {
			//System.out.println(nombre_clase);
			System.out.println("--------------------------------");
			System.out.println("su HERENCIA es : " + array[1]);
			System.out.println("su NOMBRE es : " + this.getNombre());
			System.out.println("su DNI es : " + this.getDni());
			System.out.println("su EDAD es : " + this.getEdad());
			System.out.println("--------------------------------");
		}
	}

}
