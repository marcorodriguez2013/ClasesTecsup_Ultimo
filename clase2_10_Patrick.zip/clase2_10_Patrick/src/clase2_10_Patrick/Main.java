package clase2_10_Patrick;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<Persona> persona = new ArrayList<Persona>();
		persona.add(new Cliente(0, "Pamela Rodriguez", "45463902", 29));
		persona.add(new Administrador(0, "Marco Rodriguez", "3030303", 40));
		for (Persona i : persona) {
			i.Imprimir(30, 40);
		}

	}

}
