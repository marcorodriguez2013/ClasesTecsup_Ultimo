import java.util.ArrayList;

public class Aviones {
	String modelo;
	String marca;
	int id_avion;
	ArrayList<Pilotos> pilotos;
	
}
