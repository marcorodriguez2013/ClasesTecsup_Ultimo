import java.util.ArrayList;

public class Pilotos extends Persona {
	private String licencia;
	private String dni_piloto;
	private int id_piloto;
	private ArrayList<Pilotos> pilotos;

	public Pilotos(String nombre, int edad, String licencia, String dni_piloto) {
		super(nombre, edad);
		this.licencia = licencia;
		this.dni_piloto = dni_piloto;
		this.pilotos = new ArrayList<Pilotos>();

	}

	public Pilotos() {
		super();// defecto
		this.licencia = "";
		this.dni_piloto = "";
		this.pilotos = new ArrayList<Pilotos>();
	}

	public void Imprimir() {
		System.out.println("---------------------------------");
		System.out.println("INFORMACION PILOTO");
		System.out.println("Nombre : " + this.nombre);
		System.out.println("Edad : " + this.edad);
		System.out.println("Licencia : " + this.licencia);
		System.out.println("DNI piloto : " + this.dni_piloto);
		System.out.println("---------------------------------");

	}

	public void Seleccionar_piloto(String dni_piloto) {
		boolean respuesta = true;
		for (int i = 0; i < pilotos.size(); i++) {
			if (pilotos.get(i).getDni_piloto() == dni_piloto) {
				setId_piloto(i);
				pilotos.get(i).Imprimir();
				respuesta = false;
			} 
		}
		if (respuesta) {
			System.out.println("no existe piloto");
			respuesta = true;
		}

	}

	public void AgregarPilotos(Pilotos p) {
		pilotos.add(p);
		setId_piloto(pilotos.size() - 1);

	}

	public void ListarPilotos() {
		for (int i = 0; i < pilotos.size(); i++) {
			pilotos.get(i).Imprimir();
		}
	}

	public String getLicencia() {
		return licencia;
	}

	public void setLicencia(String licencia) {
		this.licencia = licencia;
	}

	public String getDni_piloto() {
		return dni_piloto;
	}

	public void setDni_piloto(String dni_piloto) {
		this.dni_piloto = dni_piloto;
	}

	public int getId_piloto() {
		return id_piloto;
	}

	public void setId_piloto(int id_piloto) {
		this.id_piloto = id_piloto;
	}

}
