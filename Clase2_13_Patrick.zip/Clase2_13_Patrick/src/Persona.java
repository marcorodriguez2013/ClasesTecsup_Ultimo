
public class Persona {
	String nombre;
	int edad;

	public Persona(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}

	public Persona() {
		super();
		this.nombre = "Marco Antonio Rodriguez Salinas";
		this.edad = 30;
	}

}
