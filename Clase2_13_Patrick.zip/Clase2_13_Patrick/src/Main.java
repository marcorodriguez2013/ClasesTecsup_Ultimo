import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		Pilotos p = new Pilotos();
		p.AgregarPilotos(new Pilotos("marco", 30, "JAA", "45463902"));
		p.AgregarPilotos(new Pilotos("pamela", 30, "JAA", "45463903"));
		p.Seleccionar_piloto("45463902");
		
		
		
	}

}
