
public class Persona extends Thread implements Acciones {
	String nombre;
	String apellido;
	int kilometros = 0;
	Mascota mascota;
	String p = "p";

	public Persona(String nombre, String apellido, int kilometros, Mascota mascota) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.kilometros = kilometros;
		
		
	}

	public void Imprimir() {
		System.out.println("Nombre : " + nombre);
		System.out.println("Apellido : " + apellido);
		System.out.println("Kilometros : " + kilometros);
		mascota.Imprimir();

	}

	@Override
	public void caminar() {
		// TODO Auto-generated method stub
		while (this.kilometros <= 20) {
			this.kilometros += 1;
			p = "_" + p;
			System.out.println(p);
		}
		parar();
	}

	@Override
	public void correr() {

		while (this.kilometros <= 10) {
			this.kilometros += 2;

			p = "____" + p;
			System.out.println(p);
		}
		System.out.println("Dejo de correr persona , ahora caminara");
		caminar();

	}

	@Override
	public void parar() {
		System.out.println("Se canso el man");

	}

	public void run(){
		correr();
	}
}
