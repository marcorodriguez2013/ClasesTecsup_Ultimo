
public class Main {

	public static void main(String[] args) {
		Mascota m = new Mascota ("pepita", "perez", 0);
		Persona p = new Persona("Marco", "Rodriguez", 0, m);
		p.start();
		m.start();
		
	}

}
