
public class Mascota  extends Thread implements Acciones {
	public String nombre;
	public String apellido;
	public double kilometros=0;
	public String p = "G";
	public Mascota(String nombre, String apellido, double kilometros) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.kilometros = kilometros;
		
	}
	public void Imprimir() {
		System.out.println("Nombre mascota: "+nombre);
		System.out.println("Apellido apellido: "+apellido);
		System.out.println("Kilometros mascotas: "+kilometros);
	}
	@Override
	public void caminar() {
		// TODO Auto-generated method stub
		while (this.kilometros <= 20) {
			this.kilometros+=1;
			p = "_" + p;
			System.out.println(p);
		}
		parar();
	}

	@Override
	public void correr() {
		while (this.kilometros <= 10) {
			this.kilometros+=4;
			p = "____" + p;
			System.out.println(p);
		}
		System.out.println("Dejo de correr mascota, ahora caminara");
		caminar();

	}

	@Override
	public void parar() {
		System.out.println("Se canso la mascota");

	}
	public void run() {
		 correr();
	}
}
