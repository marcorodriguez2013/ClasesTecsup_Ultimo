
public interface Acciones{
	public double velocidad = 5;

	public void caminar();

	public void correr();

	public void parar();
}
