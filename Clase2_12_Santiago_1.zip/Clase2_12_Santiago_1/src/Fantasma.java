
public class Fantasma extends Enemigo{
	public Fantasma() {
		puntosvida = 50;
	}
	public void Morir() {
		super.Morir();
		System.out.println("Pero volvere por que soy el mega fantasma");
	}
	public void RecibirDanio(int i,int tipo_danio) {
		if (tipo_danio == 0) {
			System.out.println("JA lo esquive");
		}else {
			super.RecibirDanio(i);
		}
		
	}
}
