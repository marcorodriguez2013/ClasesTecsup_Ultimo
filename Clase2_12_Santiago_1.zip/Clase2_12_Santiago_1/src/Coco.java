public class Coco extends Enemigo {
	public Coco() {
		puntosvida = 5;
	}
	public void Morir() {
		super.Morir();
		System.out.println("Pero volvere");
	}
}
