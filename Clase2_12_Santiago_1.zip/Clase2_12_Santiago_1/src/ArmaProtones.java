
public class ArmaProtones extends Arma {
	public ArmaProtones() {
		sonido_disparo = "fiuuuuuuuuu";
		tipo_danio=1;
	}
}
