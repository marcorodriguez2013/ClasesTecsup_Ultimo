
public class Gargamel extends Enemigo {
	public Gargamel() {
		puntosvida = 50;
	}

	public void RecibirDanio(int i, int tipo_danio) {
		if (tipo_danio == 1) {
			System.out.println("JA lo esquive");
		} else {
			super.RecibirDanio(i);
		}

	}
}
