
public class Enemigo {
	public int puntosvida = 3;
	public boolean esta_muerto = false;

	public void Morir() {
		this.puntosvida = 0;
		System.out.println("Hoy me muero");
		this.esta_muerto = true;
	}

	public void RecibirDanio(int i) {
		if (!this.esta_muerto) {
			this.puntosvida -= i;

			if (this.puntosvida <= 0) {
				Morir();
			} else {
				System.out.println("Me diste : " + this.puntosvida);
			}
		} else {
			System.out.println("YA ESTOY MUERTO");
		}
	}
	public void RecibirDanio(int i,int tipo_danio) {
	RecibirDanio(i);
	
	}
}
