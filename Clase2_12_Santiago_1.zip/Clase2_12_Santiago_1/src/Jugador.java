import java.util.ArrayList;

public class Jugador {
	String nombre;
	int puntos_vida;
	int dinero;
	ArrayList<Arma> armas;
	int arma_seleccionada;

	public Jugador(String nombre) {
		this.nombre = nombre;
		this.puntos_vida = 100;
		this.dinero = 0;
		this.armas = new ArrayList<Arma>();
		AdquirirArma(new Arma());
	}

	public void AdquirirArma(Arma a) {
		this.armas.add(a);
		this.arma_seleccionada = armas.size() - 1;
	}
	public void CambiarArma(int a) {
		a=a-1;
		if (a<armas.size()) {
			arma_seleccionada = a;
			System.out.println("Cambio de arma");
		}else {
			System.out.println("uste no tiene esa arma");
		}
	}
	public void Disparar(Enemigo e) {
		armas.get(arma_seleccionada).Disparar(e);
	}
}
