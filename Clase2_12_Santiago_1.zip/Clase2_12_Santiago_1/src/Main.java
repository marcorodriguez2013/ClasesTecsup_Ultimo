
public class Main {

	public static void main(String[] args) {

		Fantasma f = new Fantasma();
		Gargamel g = new Gargamel();
		Jugador j = new Jugador("Marco");
		j.Disparar(f);
		j.AdquirirArma(new ArmaProtones());
		j.Disparar(f);
		j.CambiarArma(3);
		j.Disparar(f);

	}

}
