
public class Arma {
	int municiones = 10;
	int danio = 2;
	String sonido_disparo = "pum";
	int tipo_danio = 0;//0 fisico | 1 magico
	public void Disparar() {
		System.out.println(sonido_disparo);
		municiones--;
	}

	public void Disparar(Enemigo e) {
		System.out.println(sonido_disparo);
		municiones--;
		e.RecibirDanio(this.danio,this.tipo_danio);
	}
}
