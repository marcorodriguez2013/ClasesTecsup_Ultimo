package clase02_10;

import java.util.Stack;

public class Main {

	public static void main(String[] args) {
		/*SuperLista2 s2 = new SuperLista2();
		s2.push(10);
		s2.push(15);
		s2.push(18);
		System.out.println(s2.CalcularPromedio());*/
		  
		Cuadrado cuadrado = new Cuadrado(5);
		cuadrado.ImprimirCuadrado();
		Triangulo triangulo = new Triangulo(10);
		triangulo.ImprimirTriangulo();
		/*SuperLista s= new SuperLista();
		s.add(15);
		s.add(25);
		s.add(30);
		s.ImprimirLista();
		System.out.println(s.CalcularPromedio());*/

	}

}
