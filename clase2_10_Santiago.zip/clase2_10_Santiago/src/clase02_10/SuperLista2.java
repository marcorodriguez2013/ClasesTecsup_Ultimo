package clase02_10;

import java.util.Stack;

public class SuperLista2 extends Stack<Integer> {
	double resultado = 0;
	
	public Integer push(Integer i) {
		super.push(i);
		resultado += i;
		return i;

	}

	public double CalcularPromedio() {
		double res;
		res = this.resultado / this.size();
		return res;

	}
}
