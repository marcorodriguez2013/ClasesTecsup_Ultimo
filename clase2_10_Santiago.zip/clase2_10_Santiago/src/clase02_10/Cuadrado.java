package clase02_10;

public class Cuadrado extends FiguraGeometrica {

	public Cuadrado(int medida) {
		super(medida, 4);
	}

	public double ObtenerArea() {
		return medida_lado * medida_lado;
	}

	public void ImprimirCuadrado() {
		for (int i = 0; i < this.medida_lado; i++) {
			for (int j = 0; j < this.medida_lado; j++) {
				if (i == 0 || i == this.medida_lado - 1) {
					System.out.print("*");
					System.out.print(" ");
				}else {
					if(j==0 || j == this.medida_lado -1 ) {
						System.out.print("*");
						System.out.print(" ");
					}else {
						System.out.print(" ");
						System.out.print(" ");
					}
				} 
					

			}
			System.out.println();
		}
	}

}