package clase02_10;

public class Triangulo extends FiguraGeometrica {

	public Triangulo(int medida) {
		super(medida, 3);
	}

	public double ObtenerArea() {
		return medida_lado * Math.sqrt(Math.pow(medida_lado, 2) - Math.pow(medida_lado / 2, 2)) / 2;
	}

	public void ImprimirTriangulo() {
		for (int i = 1; i < this.medida_lado + 1; i++) {
			for (int j = 0; j < this.medida_lado - i; j++) {
				System.out.print(" ");
			}
			for (int k = 1; k < i; k++) {
				if (k == 1 || i == this.medida_lado) {
					System.out.print("*");
					System.out.print(" ");
				} else {
					System.out.print(" ");
					System.out.print(" ");
				}

			}
			System.out.println('*');
		}
	}

}