import java.util.ArrayList;

public class Aeropuerto {
	private String nombre;
	private int id_vuelo;
	ArrayList<Vuelos> vuelos;

	public Aeropuerto(String nombre) {
		super();
		this.nombre = nombre;
		this.vuelos = new ArrayList<Vuelos>();
	}

	public void AgregarVuelo(String hora_salida, String hora_llegada, String lugar_salida, String lugar_destino) {
		vuelos.add(new Vuelos(hora_salida, hora_llegada, lugar_salida, lugar_destino));
	}

	public void ListarVuelos() {
		for (int i = 0; i < vuelos.size(); i++) {
			System.out.println("--------------------------------");
			System.out.println("ID : " + i);
			vuelos.get(i).ImprimirInfo();
			System.out.println("--------------------------------");
		}
	}

	public void AgregarAvion(int id, String modelo, String marca) {
		vuelos.get(id).AgregarAvion(modelo, marca);
	}

	public void AgregarPiloto(int id, String nombre, int edad, String licencia, String dni_piloto) {
		vuelos.get(id).AgregarPiloto(nombre, edad, licencia, dni_piloto);
	}

	public void AgregarPasajero(int id, String nombre, int edad, char sexo) {
		vuelos.get(id).AgregarPasajero(nombre, edad, sexo);
	}

	public void InfoVuelo(int id) {
		System.out.println("ID : " + id);
		vuelos.get(id).ImprimirInfo();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getId_vuelo() {
		return id_vuelo;
	}

	public void setId_vuelo(int id_vuelo) {
		this.id_vuelo = id_vuelo;
	}

}
