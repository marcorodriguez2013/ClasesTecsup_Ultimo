
public class Vuelos {
	String hora_salida;
	String hora_llegada;
	String lugar_salida;
	String lugar_destino;
	Aviones a = new Aviones();
	Pilotos p = new Pilotos();
	Pasajeros pa = new Pasajeros();

	public Vuelos(String hora_salida, String hora_llegada, String lugar_salida, String lugar_destino) {
		super();
		this.hora_salida = hora_salida;
		this.hora_llegada = hora_llegada;
		this.lugar_salida = lugar_salida;
		this.lugar_destino = lugar_destino;
	}

	public void ListarPasajeros() {
		pa.ListarPasajeros();
	}

	public void ListarPilotos() {
		p.ListarPilotos();
	}

	public void AgregarPasajero(String nombre, int edad, char sexo) {
		pa.AgregarPasajeros(new Pasajeros(nombre, edad, sexo));
	}

	public void AgregarPiloto(String nombre, int edad, String licencia, String dni_piloto) {
		p.AgregarPilotos(new Pilotos(nombre, edad, licencia, dni_piloto));
	}

	public void AgregarAvion(String modelo, String marca) {
		a.AgregarAviones(new Aviones(modelo, marca));
	}

	public void ImprimirInfo() {
		System.out.println("Hora salida : " + this.hora_salida);
		System.out.println("Hora llegada : " + this.hora_llegada);
		System.out.println("Lugar de salida :" + this.lugar_salida);
		System.out.println("Lugar de llegada : " + this.lugar_destino);
		a.ListarAviones();
		p.ListarPilotos();
		pa.ListarPasajeros();
	}
}
