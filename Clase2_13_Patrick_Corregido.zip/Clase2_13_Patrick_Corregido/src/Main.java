import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		Aeropuerto a = new Aeropuerto("Jorge");
		a.AgregarVuelo("12:30pm", "1:30pm", "Arequipa", "Lima");
		a.AgregarAvion(0, "modelo a", "marca a");
		
	}

}
