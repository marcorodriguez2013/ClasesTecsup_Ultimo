import java.util.ArrayList;

public class Aviones {
	String modelo;
	String marca;
	int id_avion;
	ArrayList<Aviones> aviones;

	public Aviones(String modelo, String marca) {
		
		this.modelo = modelo;
		this.marca = marca;
		this.aviones = new ArrayList<Aviones>();
	}

	public Aviones() {
		
		this.modelo = "";
		this.marca = "";
		this.aviones = new ArrayList<Aviones>();

	}

	public void Imprimir() {
		System.out.println("---------------------------------");
		System.out.println("INFORMACION AVION");
		System.out.println("Modelo : " + this.modelo);
		System.out.println("Marca : " + this.marca);
		System.out.println("---------------------------------");

	}

	public void SeleccionarAviones(String modelo) {
		boolean respuesta = true;
		for (int i = 0; i < aviones.size(); i++) {
			if (aviones.get(i).getModelo() == modelo) {
				setId_avion(i);
				aviones.get(i).Imprimir();
				respuesta = false;
			}
		}
		if (respuesta) {
			System.out.println("no existe avion");
			respuesta = true;
		}

	}

	public void AgregarAviones(Aviones a) {
		aviones.add(a);
		setId_avion(aviones.size() - 1);

	}

	public void ListarAviones() {
		for (int i = 0; i < aviones.size(); i++) {
			aviones.get(i).Imprimir();
		}
	}

	public void ListarAvion() {
		aviones.get(this.getId_avion()).Imprimir();
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getId_avion() {
		return id_avion;
	}

	public void setId_avion(int id_avion) {
		this.id_avion = id_avion;
	}
}
