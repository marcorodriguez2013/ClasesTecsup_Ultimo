import java.util.ArrayList;

public class Pasajeros extends Persona {
	char sexo;
	int id_pasajero;
	ArrayList<Pasajeros> pasajeros;

	public Pasajeros(String nombre, int edad, char sexo) {
		super(nombre, edad);
		this.sexo = sexo;
		this.pasajeros = new ArrayList<Pasajeros>();
	}

	public Pasajeros() {
		super();
		this.sexo = ' ';
		this.pasajeros = new ArrayList<Pasajeros>();
	}

	public void Imprimir() {
		System.out.println("---------------------------------");
		System.out.println("INFORMACION PASAJERO");
		System.out.println("Nombre : " + this.nombre);
		System.out.println("Edad : " + this.edad);
		System.out.println("Sexo : " + this.sexo);
		System.out.println("---------------------------------");

	}

	public void SeleccionarPasajeros(String nombre) {
		boolean respuesta = true;
		for (int i = 0; i < pasajeros.size(); i++) {
			if (pasajeros.get(i).nombre == nombre) {
				setId_pasajero(i);
				pasajeros.get(i).Imprimir();
				respuesta = false;
			}
		}
		if (respuesta) {
			System.out.println("no existe pasajero");
			respuesta = true;
		}

	}

	public void AgregarPasajeros(Pasajeros p) {
		pasajeros.add(p);
		setId_pasajero(pasajeros.size() - 1);

	}

	public void ListarPasajeros() {
		for (int i = 0; i < pasajeros.size(); i++) {
			pasajeros.get(i).Imprimir();
		}
	}

	public void ListarPasajero() {
		pasajeros.get(this.getId_pasajero()).Imprimir();
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public int getId_pasajero() {
		return id_pasajero;
	}

	public void setId_pasajero(int id_pasajero) {
		this.id_pasajero = id_pasajero;
	}
}
